<!DOCTYPE html>
<html>
    <head>
    <title>Tugas Akhir Kriptografi</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
       <div>
           <ul class="nav nav-tabs nav-justified">
               <li><a href="index.html">Home</a></li>
               <li><a href="enkripsi.html">Enkripsi</a></li>
               <li><a href="dektrip.html">Deskripsi</a></li>
               <li><a href="about.html">Tentang Aplikasi</a></li>
       </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   <div class="heading">
                    <h3>Enkripsi Menggunakan Metode Caesar Cipher</h3>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="section-heading">
                        <h3>Apa Itu Caesar Cipher ?</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12">
                    <div class="col-md-12">
                        <p style="text-align: center" class="subtitle">
                            Dalam kriptografi, sandi Caesar, atau sandi geser, kode Caesar atau Geseran Caesar adalah salah satu teknik enkripsi paling sederhana dan paling terkenal. Sandi ini termasuk sandi substitusi dimana setiap huruf pada teks terang (plaintext) digantikan oleh huruf lain yang memiliki selisih posisi tertentu dalam alfabet. Misalnya, jika menggunakan geseran 3, W akan menjadi Z, I menjadi L, dan K menjadi N sehingga teks terang "wiki" akan menjadi "ZLNL" pada teks tersandi. Nama Caesar diambil dari Julius Caesar, jenderal, konsul, dan diktator Romawi yang menggunakan sandi ini untuk berkomunikasi dengan para panglimanya.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-12">
              <div class="tsub">
               <h3 style="text-align:center;">Tabel Subtitusi</h3>
                <img src="img/14-2.png">
                </div>
            </div>
        </div>
        <hr>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
<form class="form-horizontal" action="enkripsi.php" method="get">
  <div class="form-group">
    <label class="col-sm-2 control-label">Plain Text</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" placeholder="Plain Text" name="plain">
    </div>
  </div>
  <!-- <div class="form-group">
    <label class="col-sm-2 control-label">Kunci</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" placeholder="Kunci" name="kunci">
    </div>
  </div> -->
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">ENCRYPT</button>
      <button type="reset" class="btn btn-default">ULANGI</button>
    </div>
  </div>
</form>
                </div>
                 <div class="panel paneldefault">
        <div class="panel-body">
                <div class="col-md-6">
<?php
$plain = $_GET["plain"];
//Proses Enkripsi
for($i=0;$i<strlen($plain);$i++)
{
$kode[$i]=ord($plain[$i]); //Merubah ASCII ke Desimal 
$b[$i]=($kode[$i] + 3 ) % 256; //Enkripsi Caesar Cipher dengan Kunci 3
$c[$i]=chr($b[$i]);  //Merubah Desimal Ke ASCII
}
                    
echo "Plain Text : ";
for($i=0;$i<strlen($plain);$i++)
{
echo $plain[$i];
}
echo "<br>";
echo "Hasil Enkripsi : ";
$cetak = '';
for ($i=0;$i<strlen($plain);$i++)
{
echo $c[$i];
$cetak = $cetak . $c[$i];
}
?>
                </div>

            </div>
                </div>
            </div>
        </div>
    </body>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-2.2.0.min.js"?></script>
</html>
